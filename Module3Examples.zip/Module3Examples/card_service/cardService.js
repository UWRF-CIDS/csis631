"use strict";

const express = require('express');
const cors = require('cors');
const port = 8080;

// initialize up express app
const app = express();
app.use(express.json());

// Allow our webapp to access this service. For more detail, see: https://en.wikipedia.org/wiki/Cross-origin_resource_sharing
app.use(cors({ origin: 'https://ide-4fe339e8a5fd4d4e9591b51fd8cad5ce-8081.cs50.xyz' , credentials :  true}));

// This is the services base url. All other endpoints start with this.
const baseUrl = "https://ide-4fe339e8a5fd4d4e9591b51fd8cad5ce-8080.cs50.xyz";

// Define an object for storing an array of card id's
const cardData = { cards: [] };

// This function is used to read the cardData.json file if there is one, otherwise an error is thrown.
async function readCardDataFromFile() {
  const fs = require('fs').promises;
  const fileData = await fs.readFile('./cardData.json', 'utf8');

  const fileObj = JSON.parse(fileData);
  cardData.cards = fileObj.cards;
  console.log("Card data read from file!");
}

async function writeCardDataToFile() {
  let fs = require('fs').promises;
  await fs.writeFile("./cardData.json", JSON.stringify(cardData));
  console.log("Card data was saved!");
}



// Create an endpoint for a GET request for the base URL.
app.get('/', (req, res) => {
  const endpoints = {
    "cards": baseUrl + "/cards",
  };
  res.send(endpoints);
});

// Create an endpoint for a GET request to retrieve all cards.
app.get('/cards', async (req, res) => {
  if (cardData.cards.length != 0) {
    res.send(JSON.stringify(cardData));
    return;
  }

  // if cardData.cards is empty, read from the file
  try {
    await readCardDataFromFile();
  } catch(err) {
    console.log(err);
    res.send();
    return;
  }
  res.send(JSON.stringify(cardData));
});

// Create an endpoint of a POST request to save a card id.
app.post('/cards/:cardId', async (req, res) => {

  if (cardData.cards.length == 0) {
    // if cardData.cards is empty, read from the file
    try {
      await readCardDataFromFile();
    } catch(err) {
      console.log(err);
    }
  }

  if (cardData.cards.includes(req.params.cardId)) {
    res.send(JSON.stringify(cardData));
    return;
  }

  cardData.cards.push(req.params.cardId);

  try {
    await writeCardDataToFile();
  } catch(err) {
    console.log(err);
    res.send();
    return;
  }
  res.send(JSON.stringify(cardData));

});

// TODO 3 Create an endpoint for a DELETE request to remove a card id.


app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`)
});



