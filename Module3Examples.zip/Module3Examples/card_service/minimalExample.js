"use strict";

const express = require('express');
const port = 8080;

// initialize up express app
const app = express();
app.use(express.json());


app.get('/', (req, res) => {
  // any code we need
  res.send({data: 10});
});

app.get('/persons', (req, res) => {
  res.send([1, 2, 3, 4, 5]);
});

app.get('/persons/:id', (req, res) => {
  let id = req.params.id;
  res.send({"id": id});
});

app.post('/persons/:id', (req, res) => {
  let id = req.params.id;
  res.send(`Post request id is ${id}`);
});

app.delete('/persons/:id', (req, res) => {
  let id = req.params.id;
  res.send(`Delete request id is ${id}`);
});



app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`)
});