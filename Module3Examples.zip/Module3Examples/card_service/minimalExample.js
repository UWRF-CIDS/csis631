"use strict";

const express = require('express');
const port = 8080;

// initialize up express app
const app = express();
app.use(express.json());


app.get('/', (req, res) => {
  res.send("Hello!");
});



app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`)
});