
// All of the image paths organized by swapi id's.
const imagePaths = {
  1: "./img/Luke_Skywalker.png",
  2: "./img/C-3PO.png",
  3: "./img/R2-D2.png",
  4: "./img/Darth_Vader.jpg",
  5: "./img/Princess_Leia.jpg",
  10: "./img/Ben_Kenobi.png",
  13: "./img/Chewbacca.jpg",
  14: "./img/Han_Solo.jpg",
};


// fetch a random card
async function getRandomCard() {

  let char = new Character();

  // Get all available swapi id's.
  const imageKeys = Object.keys(imagePaths);
  const total = imageKeys.length;

  // Generate a random character id.
  const rnd = Math.random() * total;
  const index = Math.trunc(rnd);
  const charId = imageKeys[index];  // the random id

  await char.fetchCharacter(charId);

  // set the html for the random card using a template string
  // TODO display homeworld for the character
  document.getElementById("random_card_container").innerHTML = `
      <h1>${char.name}</h1>
      <img src="${imagePaths[charId]}"></img>
      <p>
        <button onclick="getRandomCard()">Get Random Card!</button>
        <button onclick="saveCard(${charId})">Save Card!</button>
      </p>
  `;

}


async function saveCard(charId) {

  // set the url to our card service
  const cardServiceUrl = new URL('https://ide-4fe339e8a5fd4d4e9591b51fd8cad5ce-8080.cs50.ws/cards/' + charId);
  cardServiceUrl.protocol = 'https:';

  // set options so that the method is POST
  const options = {
    method: "POST",
    body: JSON.stringify({  }),
    headers: {"Content-type": "application/json; charset=UTF-8"}
  };

  // perform POST request
  await fetch(cardServiceUrl, options);

  // Get all of my cards since the collection has changed.
  fetchMyCards();

}

// TODO 6 add a function for removing cards that makes a DELETE request to our card serivce.


async function fetchMyCards() {

  // set the url to our card service
  const cardServiceUrl = new URL('https://ide-4fe339e8a5fd4d4e9591b51fd8cad5ce-8080.cs50.ws/cards/');
  cardServiceUrl.protocol = 'https:';

  // Send GET request to get all my card id's from our card service.
  let response = await fetch(cardServiceUrl);

  console.log(response);

  // Convert the response to json object.
  const cardData = await response.json();
  const cards = cardData.cards; // reference the cards array

  // construct html for displaying all of my cards
  let html = "<h1>My Cards</h1>";


  // TODO 2 display homeworld for each character
  // TODO 5 add a "remove card" button to the html generated here.
  for (let i = 0; i < cards.length; i++) {
    let char = new Character();
    await char.fetchCharacter(cards[i]);
    html += `

      <p>
        <h2 id="myID">${char.name}</h1>
        <img id="myImage" src="${imagePaths[cards[i]]}"></img>
      </p>

    `;
  }

  // update the DOM with all of my cards.
  document.getElementById("my_cards_container").innerHTML = html;

}

