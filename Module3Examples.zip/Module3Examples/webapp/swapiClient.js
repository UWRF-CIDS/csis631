class Character {
  constructor() {
  }

  async fetchCharacter(id) {

		//let url = new URL('https://swapi.dev/api/people/' + id + '/');
		let url = new URL(`https://swapi.dev/api/people/${id}/`);
		url.protocol = 'https:';

		let response = await fetch(url);
		const data = await response.json();

		this.name = data.name;
		this.height = data.height;

		// TODO 1 Fetch homeworld data and set homeworld property for this character
  }

	static async fetchTotalCharacters(id) {

			let url = new URL('https://swapi.dev/api/people/');
			url.protocol = 'https:';

			let response = await fetch(url);
			const data = await response.json();
			return data.count;
	}

}
