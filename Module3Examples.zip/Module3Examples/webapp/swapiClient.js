//const fetch = require("node-fetch");

class Character {
  constructor() {
  }

  async fetchCharacter(id) {

		let url = new URL('https://swapi.dev/api/people/' + id + '/');
		url.protocol = 'https:';

		let response = await fetch(url);
		const data = await response.json();

		url = new URL(data.homeworld);
		url.protocol = 'https:';

		response = await fetch(url);
		const homeworldData = await response.json();


		console.log(data);
		console.log(homeworldData);

		this.name = data.name;
		this.homeworld = homeworldData.name;
  }

	static async fetchTotalCharacters(id) {

			let url = new URL('https://swapi.dev/api/people/');
			url.protocol = 'https:';

			let response = await fetch(url);
			const data = await response.json();
			return data.count;
	}

}
