"use strict"; // from ES5

function foo() {

    var variable1, variable2;

    variable1 = 5;
    varaible2 = 6;
    return variable1 + variable2;
}


console.log(foo());