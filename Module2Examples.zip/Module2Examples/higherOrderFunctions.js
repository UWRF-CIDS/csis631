// Higher Order Functions take funcs as args or return funcs
function map(arr, fn) {
  const newArr = [];

  for (let i = 0; i < arr.length; i++) {
    newArr.push(fn(arr[i]));
  }

  return newArr;
}




function addOne(num) { return num + 1 };

const x = [0,1,2,3];

console.log(map(x, addOne));












function filter(arr, fn) {
  const newArr = [];

  for (let i = 0; i < arr.length; i++) {
    if (fn(arr[i])) newArr.push(arr[i]);
  }

  return newArr;
}

function greaterThanOne(num) { return num > 1 };

//console.log(filter(x, greaterThanOne));









function reduce(arr, fn, initialVal) {
  let returnVal = initialVal;

  for (let i = 0; i < arr.length; i++) {
    returnVal = fn(returnVal, arr[i]);
  }

  return returnVal;
}


function sum(num1, num2) { return num1 + num2 };

//console.log(reduce(x, sum, 0));


