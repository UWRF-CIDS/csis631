const fetch = require("node-fetch");

console.log("about to fetch");

fetch('https://swapi.dev/api/people/3/')   // returns a promise
  .then((response) => {
	   return response.json();
  })
  .then((data) => {
	   console.log(data.name);
  })
  .then(()=> {console.log("all done!");});

console.log("fetch called!");
