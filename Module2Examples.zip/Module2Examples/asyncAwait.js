const fetch = require("node-fetch");

console.log("about to fetch");

async function getName() {
	let response = await fetch('https://swapi.dev/api/people/3/');

	let data = await response.json();
	console.log(data.name);
	console.log("all done!");
}

getName();

console.log("fetch called!!!");
