console.log('Hi');

setTimeout(function cb1() {
    console.log('cb1');
}, 5000);

console.log('Bye');
