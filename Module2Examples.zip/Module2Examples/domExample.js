function myFunction() {
  document.getElementById("myID").innerHTML = "Hello World";
}

