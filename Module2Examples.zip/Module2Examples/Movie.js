// define a class
class Movie {
  constructor(name, year) {
    this.name = name;
    this.year = year;
  }

  age() {
    let date = new Date();
    return date.getFullYear() - this.year;
  }
}

// instantiate an object
let myMovie1 = new Movie("Star Wars", 1977);
let myMovie2 = new Movie("Star Trek", 1979);






