

setTimeout(function() {
  setTimeout(function(){
    setTimeout(function(){
      console.log("hey");
    }, 1000)
  }, 1000)
}, 1000)

