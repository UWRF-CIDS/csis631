class Car {
  constructor(brand) {
    this._carname = brand;
  }

  get carname() {
    return this._carname;
  }
  set carname(x) {
    this._carname = x;
  }

  static hello() {
    return "I'm the same for all objects!";
  }

  show() {
    return 'I have a ' + this.carname;
  }
}






class Model extends Car {
  constructor(brand, mod) {
    super(brand);
    this.model = mod;
  }

}





let myCar = new Model("Ford", "Mustang");

console.log(myCar.show());