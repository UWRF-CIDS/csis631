const thisIsAConst = 50

// thisIsAConst++ // error!

let thisIsALet = 51
thisIsALet = 50
// let thisIsALet = 51 // errors!

var thisIsAVar = 50
thisIsAVar = 51
var thisIsAVar = 'new value!'


// a note about constant reference variables
const constObj = {}

// consts are still mutable
constObj.a = 'a'
console.log(constObj);

